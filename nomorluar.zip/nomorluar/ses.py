from telethon import TelegramClient, sync, events
from telethon.tl.functions.messages import GetHistoryRequest, GetBotCallbackAnswerRequest
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.errors import SessionPasswordNeededError
from telethon.errors import FloodWaitError
from time import sleep
import json,re,sys,os,requests,time,random,colorama,threading,itertools
from bs4 import BeautifulSoup

c = requests.Session()
if not os.path.exists("session"):
		os.makedirs("session")

if len(sys.argv)<1:
	 print ("\n\n\n\033[1;32mUsage : python main.py +62 doge")
	 sys.exit(1)

ua={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win32; x86) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36"}

api_id = 1998556
api_hash = '9d7911fd03267277da900bc70ca3e3ea'
phone_number = sys.argv[1]


client = TelegramClient("session/"+phone_number, api_id, api_hash)
client.connect()
if not client.is_user_authorized():
	try:
		client.send_code_request(phone_number)
		me = client.sign_in(phone_number, input('\n\n\n\033[1;0mEnter Your Code : '))
	except SessionPasswordNeededError:
		passw = input("\033[1;0mYour 2fa Password : ")
		me = client.start(phone_number,passw)
myself = client.get_me()
os.system("clear")
banner = "SUKSES AMBIL SESSION"
print(banner)
client.disconnect()
sleep(3)